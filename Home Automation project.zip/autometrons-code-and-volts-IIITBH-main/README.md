# autometrons-code-and-volts-IIITBH

# Home Automation using Audrino

In this project we have created 
* [Burglar Alarm](https://www.tinkercad.com/things/5GviuKM2IlI-smooth-borwo-habbi/editel?sharecode=LRzwfOdmERyFOLS_sW_U6_lujsnhE0oYskXtAm1Caio)
* [Garage Automation](https://www.tinkercad.com/things/i7vJGqJKpJ1-copy-of-final-solution-ques-5/editel?sharecode=PKUVQJruKngIOLZGVKNYJ4mYTH2BHD_m_cKOTeZ9HYg)
* [Home Automation](https://www.tinkercad.com/things/eUdVyAAbN1h-home-automation-v3/editel?sharecode=AAc3baJIdKG9c2pOJK0T647b9DlWYHhKYDFyQNFzES0)
* [Smart Door Lock](https://www.tinkercad.com/things/43TxgfBLG4l-copy-of-password-based-door-lock/editel?sharecode=3thtHAZLHqDBQTdP5hM2_WkdVlNe2LCwJ0yy_bk-ML8)
* [Water Dispenser](https://www.tinkercad.com/things/fXK0yGGA9gc-copy-of-automatic-water-dispenser-with-lcd-and-an-interrupt/editel?sharecode=oD1el8rVS5FIfHILEEOBDrFopb-U40gysLhF2JaN6aE)
* [Home automation using IOT]()




## Authors

- [RajivRanjan](https://www.github.com/rajiv-dotcom)
- [Sourabh](https://www.github.com/CyborgFerolynx)
- [Ankit Kumar](https://github.com/ankit8084)


  
